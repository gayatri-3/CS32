#include "CarMap.h"
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

void test2() {

    CarMap cm1; 
    cm1.addCar("123ABC");
    cm1.addCar(""); //empty string with addCar
    assert(cm1.miles("123ABC") == 0.0);
    assert(cm1.miles("123abc") == -1); //string not in map miles
    assert(cm1.fleetSize() == 2);
    assert(!cm1.drive("123abc", 10.0)); //plate not in map so won't go 
    assert(!cm1.drive("123ABC", -10.0)); //invalid distance
    assert(cm1.drive("123ABC", 0.0));
    assert(cm1.miles("123ABC") == 0.0);
    assert(cm1.drive("123ABC", 10.0));
    assert(cm1.miles("123ABC") == 10.0);

    cerr << endl; 
    cm1.print();

}

int main()
{
    test2();
    cout << "Passed all tests" << endl;
}

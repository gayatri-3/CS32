#ifndef CARMAP_INCLUDED
#define CARMAP_INCLUDED

#include "Map.h"
#include <string> 

class CarMap
{
public:
    CarMap(); 

    bool addCar(std::string license);

    double miles(std::string license) const;

    bool drive(std::string license, double distance);

    int fleetSize() const;  

    void print() const;

private:
    
    Map m_CarMap; 
   
};

#endif //CARMAP_INCLUDED
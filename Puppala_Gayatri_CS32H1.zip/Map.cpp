#include "Map.h"
#include <iostream>
#include <string>
using namespace std; 

Map::Map()
{
	sizeMap = 0; 
	
}

bool Map::empty() const {
	return (sizeMap == 0);
}

int Map::size() const {
	return sizeMap; 
}

bool Map::insert(const KeyType& key, const ValueType& value) {
	cerr << "entered insert function" << endl;
	if (sizeMap == DEFAULT_MAX_ITEMS) { //map is full
		return false; 
	}
	cerr << size() << endl; 
	for (int i = 0; i < sizeMap; i++) {
		if (pairsArr[i].m_key == key) {
			cerr << "inside for to find key in map array" << endl;
			return false; //key exists in map array

		}
	}

	//add new pair to end of array
	cerr << "start add " << endl; 
	pairsArr[sizeMap].m_key = key; 
	pairsArr[sizeMap].m_value = value;
	sizeMap++;
	cerr << "exit insert " << endl;
	return true; 
	
}

bool Map::update(const KeyType& key, const ValueType& value) {
	for (int i = 0; i < sizeMap; i++) {
		if (pairsArr[i].m_key == key) {//if key exists in map array
			pairsArr[i].m_value = value;
			return true;
		}
	}

	return false; 

}

bool Map::insertOrUpdate(const KeyType& key, const ValueType& value) {
	if (update(key, value)) {
		return true;
	}
	else if (insert(key, value)) {
		return true; 
	}
	else {
		return false; 
	}

}

bool Map::erase(const KeyType& key) {
	for (int i = 0; i < sizeMap; i++) {
		if (pairsArr[i].m_key == key) { //if key exists in map
			for (int j = 0; j < sizeMap-i-1; j++) {
				pairsArr[i + j].m_key = pairsArr[i + j + 1].m_key;
				pairsArr[i + j].m_value = pairsArr[i + j + 1].m_value;
			}
			sizeMap--;
			return true;
		}
	}

	return false;

}

bool Map::contains(const KeyType& key) const {
	for (int i = 0; i < sizeMap; i++) {
		if (pairsArr[i].m_key == key) {//if key exists in map array
			return true;
		}
	}

	return false; 

}

bool Map::get(const KeyType& key, ValueType& value) const {
	for (int i = 0; i < size(); i++) {
		if (pairsArr[i].m_key == key) {//if key exists in map array
			value = pairsArr[i].m_value;
			return true; 
		}
	}
	return false; 

}

bool Map::get(int i, KeyType& key, ValueType& value) const { 
	if (i >= 0 && i < size()) {
		int count = 0;
		for (int k = 0; k < size(); k++) {
			count = 0;
			for (int j = 0; j < size(); j++) { //go through the keys and count how many bigger
				if ( pairsArr[k].m_key > pairsArr[j].m_key) {
					count++;
					
				}
			}
			if (count == i) {
				key = pairsArr[k].m_key;
				value = pairsArr[k].m_value;
				
				return true;
			}
		}
		
	}
	return false; 

}

void Map::swap(Map& other) {
	Map temp;
	temp.sizeMap = sizeMap; 
	sizeMap = other.sizeMap; 
	other.sizeMap = temp.sizeMap; 

	for (int i = 0; i < size(); i++) {
		temp.pairsArr[i].m_key = pairsArr[i].m_key;
		pairsArr[i].m_key = other.pairsArr[i].m_key;
		other.pairsArr[i].m_key = temp.pairsArr[i].m_key;
	}

	for (int i = 0; i < size(); i++) {
		temp.pairsArr[i].m_value = pairsArr[i].m_value;
		pairsArr[i].m_value = other.pairsArr[i].m_value;
		other.pairsArr[i].m_value = temp.pairsArr[i].m_value;
	}

	cerr << endl << "done swap" << endl;

}

void Map::dump() const {
	cerr << "sizeMap: " << size() << endl;
	for (int i = 0; i < size(); i++) {
		cerr << pairsArr[i].m_key << " " << pairsArr[i].m_value << endl;
	}
}
#include "newMap.h"
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

Map::Map()
{
	m_sizeMap = 0;
	m_maxSize = DEFAULT_MAX_ITEMS; 
	m_pointPairArr = new pair[m_maxSize];
}

Map::Map(const int maxSize) { 
	if (maxSize < 0) {
		cout << "invalid max size" << endl;
		exit(1);
	}
	m_sizeMap = 0;
	m_maxSize = maxSize; 
	m_pointPairArr = new pair[m_maxSize];
}

// copy constructor -- when need to make copy of the entire map, creates brand new map
Map::Map(const Map& other) {
	m_maxSize = other.m_maxSize; // creates copy
	m_sizeMap = other.m_sizeMap; 

	m_pointPairArr = new pair[m_maxSize]; //dynamiclaly allocate new array of pairs
	for (int i = 0; i < size(); i++) { //copy over
		m_pointPairArr[i].m_key = other.m_pointPairArr[i].m_key;
		m_pointPairArr[i].m_value = other.m_pointPairArr[i].m_value;
	}
}

//assignment operator -- leverege copy constructor to copy and swap, reassigning 
Map& Map::operator=(const Map& other) { //make this.map = other      v=(u=s)
									
	if (this != &other) { //if they are same map meaning same addresses
		Map temp(other);
		swap(temp);
	}

	return *this;
}

//destructor -- make sure to delete dynamically allocated variables 
Map::~Map()
{
	delete [] m_pointPairArr;	
}



bool Map::empty() const {
	return (m_sizeMap == 0);
}

int Map::size() const {
	return m_sizeMap;
}

bool Map::insert(const KeyType& key, const ValueType& value) {
	cerr << "entered insert function" << endl;
	if (m_sizeMap == m_maxSize) { //map is full
		return false;
	}
	cerr << size() << endl; //p
	for (int i = 0; i < size(); i++) {
		if (m_pointPairArr[i].m_key == key) {
			cerr << "inside for to find key in map array" << endl;
			return false; //key exists in map array

		}
	}

	//add new pair to end of array
	cerr << "start add " << endl; // gets here and stops 
	cerr << "m_sizeMap: " << m_sizeMap << "   m_maxSize:  " << m_maxSize << endl;
	m_pointPairArr[m_sizeMap].m_key = key;
	m_pointPairArr[m_sizeMap].m_value = value;
	m_sizeMap++;
	cerr << "exit insert " << endl;
	return true;

}

bool Map::update(const KeyType& key, const ValueType& value) {
	for (int i = 0; i < m_sizeMap; i++) {
		if (m_pointPairArr[i].m_key == key) {//if key exists in map array
			m_pointPairArr[i].m_value = value;
			return true;
		}
	}

	return false;

}

bool Map::insertOrUpdate(const KeyType& key, const ValueType& value) {
	if (update(key, value)) {
		return true;
	}
	else if (insert(key, value)) {
		return true;
	}
	else {
		return false;
	}

	
}

bool Map::erase(const KeyType& key) {
	for (int i = 0; i < m_sizeMap; i++) {
		if (m_pointPairArr[i].m_key == key) { //if key exists in map
			for (int j = 0; j < size() - i - 1; j++) {
				m_pointPairArr[i + j].m_key = m_pointPairArr[i + j + 1].m_key; 
				m_pointPairArr[i + j].m_value = m_pointPairArr[i + j + 1].m_value;
			}
			m_sizeMap--;
			return true;
		}
	}

	return false;

}

bool Map::contains(const KeyType& key) const {
	for (int i = 0; i < size(); i++) {
		if (m_pointPairArr[i].m_key == key) {//if key exists in map array
			return true;
		}
	}

	return false;

}

bool Map::get(const KeyType& key, ValueType& value) const {
	for (int i = 0; i < size(); i++) {
		if (m_pointPairArr[i].m_key == key) {//if key exists in map array
			value = m_pointPairArr[i].m_value;
			return true;
		}
	}
	return false;

}

bool Map::get(int i, KeyType& key, ValueType& value) const { 
	if (i >= 0 && i < size()) {
		int count = 0;
		for (int k = 0; k < size(); k++) {
			count = 0;
			for (int j = 0; j < size(); j++) { //go through the keys and count how many bigger
				if (m_pointPairArr[k].m_key > m_pointPairArr[j].m_key) {
					count++;

				}
			}
			if (count == i) {
				key = m_pointPairArr[k].m_key;
				value = m_pointPairArr[k].m_value;
				cerr << "key   " << key << endl;
				cerr << "value   " << value << endl;
				return true;
			}
		}
	}
	return false;

}

void Map::swap(Map& other) { 
	//swap using temp pointer
	
	int tempSize = m_sizeMap;
	m_sizeMap = other.m_sizeMap;
	other.m_sizeMap = tempSize;

	int tempMax = m_maxSize;
	m_maxSize = other.m_maxSize;
	other.m_maxSize = tempMax;

	pair* tempPointer = m_pointPairArr; 
	m_pointPairArr = other.m_pointPairArr;
	other.m_pointPairArr = tempPointer;

	cerr << "done swap" << endl;

}

void Map::dump() const {
	cerr << "sizeMap: " << size() << endl;
	for (int i = 0; i < size(); i++) {
		cerr << m_pointPairArr[i].m_key << " " << m_pointPairArr[i].m_value << endl;
	}
}

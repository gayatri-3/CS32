#include "CarMap.h"
#include <iostream>
#include <string>
using namespace std; 

CarMap::CarMap() {
    
}

bool CarMap::addCar(std::string license) {
    return m_CarMap.insert(license, 0.0);

}

double CarMap::miles(std::string license) const {                                  
    double milesDriven = -1;
    if (m_CarMap.contains(license)  && m_CarMap.get(license, milesDriven)) {
        return milesDriven; 
    }
    else {
        return -1;
    }

}

bool CarMap::drive(std::string license, double distance) {                          
    if (distance < 0 || !m_CarMap.contains(license)) {
        return false; 
    }
    else {
        m_CarMap.update(license, miles(license) + distance);
        return true; 
    }

}

int CarMap::fleetSize() const {
    return m_CarMap.size();

    
}

void CarMap::print() const {                                                                
    KeyType emptyKey = "";
    ValueType emptyValue = 0.0;
    for (int i = 0; i < m_CarMap.size(); i++) {
        if (m_CarMap.get(i, emptyKey, emptyValue)) {
            cout << emptyKey << " " << emptyValue << endl;
        }
    }

}


#ifndef NEWMAP_INCLUDED
#define NEWMAP_INCLUDED

#include <string>

using KeyType = std::string;
using ValueType = double;

const int DEFAULT_MAX_ITEMS = 260;

class Map
{
private:
    struct pair {
        KeyType m_key;
        ValueType m_value;
    };

    pair* m_pointPairArr = nullptr; //pointer to array 
    int m_sizeMap;
    int m_maxSize; 
public:
    Map();
    
    //destructor
    ~Map();

    //overloaded constructor
    Map(const int maxSize);

    //copy constructor 
    Map(const Map& other);

    //assignment operator
    Map& operator=(const Map& other);

    bool empty() const;  

    int size() const;    

    bool insert(const KeyType& key, const ValueType& value); 

    bool update(const KeyType& key, const ValueType& value); 

    bool insertOrUpdate(const KeyType& key, const ValueType& value); 

    bool erase(const KeyType& key);

    bool contains(const KeyType& key) const;

    bool get(const KeyType& key, ValueType& value) const; 

    bool get(int i, KeyType& key, ValueType& value) const; 

    void swap(Map& other);

    void dump() const;

};

#endif //NEWMAP_INCLUDED

